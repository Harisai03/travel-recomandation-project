function showCountryRecommendations() {
  const country = document.getElementById('countrySelect').value;
  const container = document.getElementById('countryRecommendations');
  container.innerHTML = '';
  if (country === 'india') {
    container.innerHTML = `
      <h3>India</h3>
      <img src="images/india1.jpg" alt="India 1" style="width:200px;height:150px;">
      <img src="images/india2.jpg" alt="India 2" style="width:200px;height:150px;">
    `;
  }
}
